<?php

return array(
        "name"          => "vatapi",
        "version"       => "3.5",
        "author"        => "vat",
        "website"       => "vat78.ru",
        "description"   => "Addition API features for my Android application"
    
);
?>
