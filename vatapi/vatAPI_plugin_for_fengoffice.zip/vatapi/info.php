<?php

return array(
        "name"          => "vatapi",
        "version"       => "1",
        "author"        => "vat",
        "website"       => "vat78.ru",
        "description"   => "Addition API features for my Android application"
    
);
?>
